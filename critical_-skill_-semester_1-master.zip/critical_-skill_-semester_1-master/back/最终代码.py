import requests
import time
import json
import pandas as pd
import pymysql
import mysql.connector
from sqlalchemy import create_engine
#数据库用户名root:密码@服务器IP:端口/数据库名?连接选项

name = 'rootall'
key = '123456'
ku_name = 'house'
ku_cri = 'critical skill'
#-----------------宿舍校园网ip地址+端口--------------------
ip = '10.133.173.88'
port1 = '3306'
#------------------流量ip地址+端口--------------------
ip_liuliang = '192.168.30.111'
port2 = '3306'
#------------------本地ip地址+端口--------------------
ip_bendi = '127.0.0.1'
port3 = '3306'


conn = create_engine('mysql+pymysql://%s:%s@%s:%s/%s?charset=utf8'%(name,key,ip_bendi,port1,ku_name))
#共31个省份，36个月的数据，逐月更新
locations = ['北京','天津','河北','山西','内蒙古','辽宁','吉林','黑龙江','上海','江苏','浙江','安徽','福建','江西','山东','河南','湖北','湖南','广东','广西','海南','重庆','四川','贵州','云南','西藏','陕西','甘肃','青海','宁夏','新疆']
#山西=shangxi，陕西=shanxi
provinces_lst = ['beijing','tianjin','hebei','shangxi','neimenggu','liaoning','jilin','heilongjiang','shanghai','jiangsu','zhejiang','anhui','fujian','jiangxi','shandong','henan','hubei','hunan','guangdong','guangxi','hainan','chongqing','sichuan','guizhou','yunnan','xizang','shanxi','gansu','qinghai','ningxia','xinjiang']
#--------------------------------------------------------------------爬取data板块-------------------------------------------------------------------------------
def getTime():
    return int(round(time.time() * 1000))
#解决无证书安全问题
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

#设置请求url列表，分别为"房地产投资累计值（亿元）""房地产投资累计增长（%）""房地产住宅投资累计值（亿元）""房地产住宅投资累计增长（%）""商品房销售额累计值（亿元）""商品房销售额增长率（%）""商品房住宅销售额累计值（亿元）""商品房住宅销售额累计增长（%）"
urls=['''https://data.stats.gov.cn/easyquery.htm?m=QueryData&dbcode=fsyd&rowcode=sj&colcode=reg&wds=[{"wdcode":"zb","valuecode":"A140101"}]&dfwds=[{"wdcode":"sj","valuecode":"LAST36"}]&k1=1681752168442''',
     '''https://data.stats.gov.cn/easyquery.htm?m=QueryData&dbcode=fsyd&rowcode=sj&colcode=reg&wds=[{"wdcode":"zb","valuecode":"A140102"}]&dfwds=[{"wdcode":"sj","valuecode":"LAST36"}]&k1=1681796797263''',
     '''https://data.stats.gov.cn/easyquery.htm?m=QueryData&dbcode=fsyd&rowcode=sj&colcode=reg&wds=[{"wdcode":"zb","valuecode":"A140103"}]&dfwds=[{"wdcode":"sj","valuecode":"LAST36"}]&k1=1681797046466''',
     '''https://data.stats.gov.cn/easyquery.htm?m=QueryData&dbcode=fsyd&rowcode=sj&colcode=reg&wds=[{"wdcode":"zb","valuecode":"A140104"}]&dfwds=[{"wdcode":"sj","valuecode":"LAST36"}]&k1=1681797069633''',
      '''https://data.stats.gov.cn/easyquery.htm?m=QueryData&dbcode=fsyd&rowcode=sj&colcode=reg&wds=[{"wdcode":"zb","valuecode":"A140901"}]&dfwds=[{"wdcode":"sj","valuecode":"LAST36"}]&k1=1681802664452''',
      '''https://data.stats.gov.cn/easyquery.htm?m=QueryData&dbcode=fsyd&rowcode=sj&colcode=reg&wds=[{"wdcode":"zb","valuecode":"A140902"}]&dfwds=[{"wdcode":"sj","valuecode":"LAST36"}]&k1=1681802718069''',
      '''https://data.stats.gov.cn/easyquery.htm?m=QueryData&dbcode=fsyd&rowcode=sj&colcode=reg&wds=[{"wdcode":"zb","valuecode":"A140A01"}]&dfwds=[{"wdcode":"sj","valuecode":"LAST36"}]&k1=1681811146548''',
      '''https://data.stats.gov.cn/easyquery.htm?m=QueryData&dbcode=fsyd&rowcode=sj&colcode=reg&wds=[{"wdcode":"zb","valuecode":"A140A02"}]&dfwds=[{"wdcode":"sj","valuecode":"LAST36"}]&k1=1681811265491''']
headers={
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.57'
}
sheetnames=["房地产投资累计值（亿元）","房地产投资累计增长率","房地产住宅投资累计值（亿元）","房地产住宅投资累计增长率","商品房销售额累计值（亿元）","商品房销售额增长率","商品房住宅销售额累计值（亿元）","商品房住宅销售额累计增长率"]
sheetnames_num=["house1","house2","house3","house4","house5","house6","house7","house8"]
t=0#计次
whole_data_lst = []
for url in urls:
    key={
        'm':'QueryData',
        'dbcode':'fsyd',
        'rowcode':'sj',
        'colcode':'zb',
        'wds':'[{"wdcode":"zb","valuecode":"A140101"}]',
        'dfwds':'[{"wdcode":"sj","valuecode":"LAST36"}]',

    }
    response=requests.get(url=url,headers=headers,params=key,verify=False).text
    js=json.loads(response)
    with open('data.json','w') as fp:
        fp.write(response)
    returndata_dic = js['returndata']
    datanodes_lst = returndata_dic['datanodes']

    datas=[]#所有数据值储存在data里
    times=[]#所有时间值
    locations=['北京','天津','河北','山西','内蒙古','辽宁','吉林','黑龙江','上海','江苏','浙江','安徽','福建','江西','山东','河南','湖北','湖南','广东','广西','海南','重庆','四川','贵州','云南','西藏','陕西','甘肃','青海','宁夏','新疆']

    for num in range(0,len(datanodes_lst)):

        single_data_dic = datanodes_lst[num]
        data_dic = single_data_dic["data"]
        data = data_dic["data"]
        if data == 0 :
            continue
        else:
            datas.append(data)
            #筛选时间
            time = (((datanodes_lst[num])["wds"])[2])["valuecode"]
            times.append(time)
    #36为36个月，现要去除其中的空数据的月份，故36应改为datas集中的数据量/31个省份
    actual_datanum = int(len(datas)/31)
    times = times[0:actual_datanum]
    times_dic={}
    times_dic["时间"] = times
    #数据分省处理
    datas_loc=[]
    for loc_num in range(len(locations)):
        datas_loc.append(list(datas[ actual_datanum*loc_num : actual_datanum*(loc_num+1) ]))#从当前位置往后找36个成为新列表

    #省份与数据结合
    combine_loc_data_dic = {}
    for locnum in range(len(locations)):
        combine_loc_data_dic[locations[locnum]]=datas_loc[locnum]

    # #总字典

    general_dic = {**times_dic, **combine_loc_data_dic}

    whole_data_lst.append(general_dic)
    #print(general_dic)#获取字典型数据
    t+=1
#--------------------------------------------------------------------转入数据库板块-------------------------------------------------------------------------------
#print(whole_data_lst)
#-----------------------------------------创建表-----------------------------------------
# mydb = mysql.connector.connect(
#     host="127.0.0.1",
#     user = "root",
#     passwd = "040426",
#     database = "第一次尝试0515"
# )
# for name in sheetnames:
#     mycursor = mydb.cursor()
#     mycursor.execute("CREATE TABLE %s (name VARCHAR(255), address VARCHAR(255))"%(name))
#----------------------------------------按列插入数据实现，8house的建表及插入------------------------------------------
for i in range(len(whole_data_lst)):
    df = pd.DataFrame(whole_data_lst[i])
    df.to_sql('%s'%(sheetnames_num[i]), con=conn,if_exists='replace',index=False)
#----------------------------------------实现各省的录入-------------------------------------------------------------
new_whole_provice_lst = []
for p in range(len(provinces_lst)):#len(provinces_lst)=省份个数
    #需写入单张表的内容
    new_frame_dic = {}
    new_frame_dic["时间"] = (whole_data_lst[0])["时间"]
    for num in range(len(sheetnames)):#len(sheetnames)=表数8
        new_frame_dic[sheetnames[num]]=(whole_data_lst[num])["%s"%(locations[p])]
    new_whole_provice_lst.append(new_frame_dic)#获得各省份的总lst表
for i in range(len(new_whole_provice_lst)):
    df = pd.DataFrame.from_dict(new_whole_provice_lst[i], orient='index')
    df_new = df.fillna(value=0)
    df_nn = df_new.T
    df_nn.to_sql("%s"%(provinces_lst[i]),con=conn,if_exists='replace',index=False)