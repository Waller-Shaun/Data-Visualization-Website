<script>
 var orientLayer = document.getElementById("orientLayer");
 //判断横屏竖屏
 function checkDirect() {
	 if (document.documentElement.clientWidth >= document.documentElement.clientHeight) {
		 return "portrait"; //横屏
	 } else {
		 return  "landscape"; //竖屏
	 }
 }
 //显示屏幕方向提示浮层
 function orientNotice() {
	 var orient = checkDirect();
	 if (orient == "landscape") {
		 orientLayer.style.display = "none";
	 } else {
		 orientLayer.style.display = "block";
	 }
 }
 //给屏幕添加监听事件
 function init() {
	 orientNotice();
	 window.addEventListener("onorientationchange" in window ? "orientationchange" : "resize", function() {
		 setTimeout(orientNotice, 200);
	 })
 }
 init();
</script>