myChart.on('click', function (args) {
    if (args.data.name == '北京') {
        location.href = 'beijing';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '天津') {
        location.href = 'tianjin';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '河北') {
        location.href = 'hebei';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '山西') {
        location.href = 'shanxi';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '内蒙古') {
        location.href = 'neimenggu';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '辽宁') {
        location.href = 'liaoning';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '吉林') {
        location.href = 'jilin';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '黑龙江') {
        location.href = 'heilongjiang';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '上海') {
        location.href = 'shanghai';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '江苏') {
        location.href = 'jiangsu';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '浙江') {
        location.href = 'zhejiang';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '安徽') {
        location.href = 'anhui';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '福建') {
        location.href = 'fujian';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '江西') {
        location.href = 'jiangxi';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '山东') {
        location.href = 'shandong';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '河南') {
        location.href = 'henan';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '湖北') {
        location.href = 'hubei';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '湖南') {
        location.href = 'hunan';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '广东') {
        location.href = 'guangdong';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '广西') {
        location.href = 'guangxi';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '海南') {
        location.href = 'hainan';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '重庆') {
        location.href = 'chongqing';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '四川') {
        location.href = 'sichuan';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '贵州') {
        location.href = 'guizhou';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '云南') {
        location.href = 'yunnan';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '西藏') {
        location.href = 'xizang';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '陕西') {
        location.href = 'shangxi';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '甘肃') {
        location.href = 'gansu';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '青海') {
        location.href = 'qinghai';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '宁夏') {
        location.href = 'ningxia';
    }
})
myChart.on('click', function (args) {
    if (args.data.name == '新疆') {
        location.href = 'xinjiang';
    }
})

//港澳台无数据不予展示
// myChart.on('click', function (args) {
//     if (args.data.name == '台湾') {
//         location.href = 'team';
//     }
// })
// myChart.on('click', function (args) {
//     if (args.data.name == '香港') {
//         location.href = 'team';
//     }
// })
// myChart.on('click', function (args) {
//     if (args.data.name == '澳门') {
//         location.href = 'team';
//     }
// })


