function Sideways() {
    if (window.orientation== 180 || window.orientation== 0) {   
        window.location.reload();} 
    if (window.orientation== 90 || window.orientation== -90) { 
        window.location.reload();}
}
window.addEventListener("onorientationchange" in window ? "orientationchange" : "resize", Sideways, false);