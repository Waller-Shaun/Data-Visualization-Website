<!--手机横屏提示-->
<script>
	function hengshuping(){
		if(window.orientation==0||window.orientation==-360){
				window.location.reload();//页面刷新
		}
	}
	window.addEventListener("onorientationchange" in window ? "orientationchange" : "resize", hengshuping, false);
</script>