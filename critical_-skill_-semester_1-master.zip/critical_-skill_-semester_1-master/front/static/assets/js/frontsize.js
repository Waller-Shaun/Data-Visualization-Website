function fontSize(px) {  //传入字体大小
    let clientWidth = window.innerWidth || document.body.clientWidth; //屏幕尺寸
    if (!clientWidth) {
      return 0;
    }
    let fontSize = clientWidth / 1920; //设计稿尺寸
    return px * fontSize;  //转换为 rem的布局返回出去
}

