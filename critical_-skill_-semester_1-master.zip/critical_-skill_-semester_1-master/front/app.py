from flask import Flask,render_template
import pymysql

# 从Flask包中导入Flask类

app = Flask(__name__)
# 从Flask类创建一个app对象
# __name__代表当前app.py这个模块

# 首页
@app.route('/')
#创建一个根路由(本地叫根路径)和视图函数的映射
def index():
    mainpart = []
    lis2 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from house1"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
            mainpart.append(item)
    mainpart = mainpart[0]
    for i in mainpart:
        lis2.append(float(i))
    lis2[0] = mainpart[0]
    cur.close()
    cur.close()
    print(lis2)
    return render_template("index.html",lis2=lis2)

@app.route('/index')
def home():
    #return render_template("index.html")
    return index()

# 团队页
@app.route('/team')
def team():
    return render_template("team.html")

# 省份页
@app.route('/beijing')
def area01():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from beijing"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("beijing.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/tianjin')
def area02():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from tianjin"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("tianjin.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/hebei')
def area03():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from hebei"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("hebei.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/shanxi')
def area04():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from shanxi"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("shanxi.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/neimenggu')
def area05():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from neimenggu"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("neimenggu.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/liaoning')
def area06():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from liaoning"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("liaoning.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/jilin')
def area07():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from jilin"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("jilin.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/heilongjiang')
def area08():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from heilongjiang"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("heilongjiang.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/shanghai')
def area09():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from shanghai"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("shanghai.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/jiangsu')
def area10():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from jiangsu"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("jiangsu.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/zhejiang')
def area11():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from zhejiang"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("zhejiang.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/anhui')
def area12():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from anhui"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("anhui.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/fujian')
def area13():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from fujian"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("fujian.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/jiangxi')
def area14():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from jiangxi"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("jiangxi.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/shandong')
def area15():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from shandong"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("shandong.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/henan')
def area16():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from henan"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("henan.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/hubei')
def area17():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from hubei"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("hubei.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/hunan')
def area18():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from hunan"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("hunan.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/guangdong')
def area19():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from guangdong"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("guangdong.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/guangxi')
def area20():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from guangxi"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("guangxi.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/hainan')
def area21():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from hainan"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("hainan.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/chongqing')
def area22():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from chongqing"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("chongqing.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/sichuan')
def area23():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from sichuan"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("sichuan.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/guizhou')
def area24():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from guizhou"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("guizhou.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/yunnan')
def area25():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from yunnan"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("yunnan.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/xizang')
def area26():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from xizang"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("xizang.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/shangxi')
def area27():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from shangxi"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("shangxi.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/gansu')
def area28():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from gansu"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("gansu.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/qinghai')
def area29():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from qinghai"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("qinghai.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/ningxia')
def area30():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from qinghai"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("ningxia.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)

@app.route('/xinjiang')
def area31():
    lis1 = []
    con = pymysql.connect(
        host='localhost',
        port=3306,
        user='rootall',
        passwd='123456',
        db='house',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select * from xinjiang"
    data = cur.execute(sql)
    result=cur.fetchall()
    for item in result:
        lis1.append(item)
    time = [i[0] for i in lis1]
    time_list = []
    for single_time in time:
        new_tume = single_time[0:4] + '/' + single_time[4:]
        time_list.append(new_tume)
    value_1 = [] #房地产投资累计增长率(%)
    value_5 = [] #商品房销售累计增长率(%)
    most_value = [] #年末房地产投资累计值
    most_percent = [] #年末房地产累计增速
    for percent in lis1:
        value_1.append(float(percent[2]))
        value_5.append(float(percent[8]))
        if "12" in percent[0]:
            most_value.append(int(float(percent[1])))
            most_percent.append(int(float(percent[2])))
    value_2 = []    #房地产住宅投资累计值
    value_3 = []    #商品房住宅销售累计值
    value_4 = []    #房地产住宅投资累计值与商品房住宅销售额差值
    value_6 = []    #房地产投资累计值
    value_7 = []    #商品房销售累计值
    for value in lis1:
        value_2.append(float(value[3]))
        value_3.append(float(value[7]))
        value_4.append(float(value[7])-float(value[3]))
        value_6.append(float(value[1]))
        value_7.append(float(value[5]))
    cur.close()
    cur.close()
    print(lis1)
    print(value_2)
    print(most_value)
    return render_template("xinjiang.html",lis1=lis1,time_list=time_list,value_1=value_1,value_2=value_2,value_3=value_3,value_4=value_4,value_5=value_5,most_value=most_value,value_6=value_6,value_7=value_7,most_percent=most_percent)


if __name__ == '__main__':
    app.run(host='0.0.0.0',port="8000",debug=True)


# 修改 host 可以实现其他电脑访问我电脑上的flask项目
# 在运行的左边下拉列表选编辑配置，其他选项内写入--host=0.0.0.0
# 修改端口号，其他端口被占用时
# 同上--port=端口号
